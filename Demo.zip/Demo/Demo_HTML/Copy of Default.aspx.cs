﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;

public partial class _Default : Page
{
    DirectoryInfo di = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
    string strParentPath;
    string strFilePath, strParamFilePath;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        lblPath.Text = "";
        try
        {
            string strValue = string.Empty;
            if (chkFirefox.Checked == true)
            {
                strValue = "1";
            }
            if (chkChrome.Checked == true)
            {
                strValue = "2";
            }
            //if (ChkIntExp.Checked == true)
            //{
            //    strValue = "3";
            //}
            //System.IO.File.WriteAllLines(@"C:\Program Files (x86)\Jenkins\jobs\JustLogin\workspace\usebrowser.txt", "");
            //System.IO.File.WriteAllLines(@"C:\Program Files (x86)\Jenkins\jobs\JustLogin\workspace\usebrowser.txt");
            System.IO.File.WriteAllText(@"C:\Program Files (x86)\Jenkins\jobs\JustLogin\workspace\bin\Debug\usebrowser.txt", "");
            System.IO.File.WriteAllText(@"C:\Program Files (x86)\Jenkins\jobs\JustLogin\workspace\bin\Debug\usebrowser.txt", strValue);

            ExeConfigurationFileMap configMap = new ExeConfigurationFileMap { ExeConfigFilename = @"C:\Program Files (x86)\Jenkins\jobs\JustLogin\workspace\App.config" };
            Configuration config = ConfigurationManager.OpenMappedExeConfiguration(configMap, ConfigurationUserLevel.None);
            // Add an Application Setting.
            config.AppSettings.Settings.Remove("UseBrowser");
            config.AppSettings.Settings.Add("UseBrowser", strValue);
            // Save the configuration file.
            config.Save(ConfigurationSaveMode.Modified);
            // Force a reload of a changed section.
            ConfigurationManager.RefreshSection("appSettings");

            di = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
            strParentPath = di.ToString(); //di.Parent.FullName + "\\ExportoryAutomation\\bin\\debug\\";
            strFilePath = strParentPath + "testlist.txt";

            string strNameSpce = "TestCases.TestSuites.";
            if (!File.Exists(strFilePath)) File.Create(strFilePath);
            if (File.Exists(strFilePath))
            {
                File.Delete(strFilePath);
                using (StreamWriter sw = new StreamWriter(strFilePath))
                {
                    sw.AutoFlush = true;

                    ///////////////////////////////Login//////////////////////////////////////

                    if (value1.Checked) sw.WriteLine(strNameSpce + value1.Value);
                    if (value2.Checked) sw.WriteLine(strNameSpce + value2.Value);
                    if (value3.Checked) sw.WriteLine(strNameSpce + value3.Value);
                    if (value4.Checked) sw.WriteLine(strNameSpce + value4.Value);
                    if (value5.Checked) sw.WriteLine(strNameSpce + value5.Value);
                    if (value6.Checked) sw.WriteLine(strNameSpce + value6.Value);
                    if (value7.Checked) sw.WriteLine(strNameSpce + value7.Value);
                    if (value8.Checked) sw.WriteLine(strNameSpce + value8.Value);
                    if (value9.Checked) sw.WriteLine(strNameSpce + value9.Value);
                    if (value10.Checked) sw.WriteLine(strNameSpce + value10.Value);
                    if (value11.Checked) sw.WriteLine(strNameSpce + value11.Value);
                    if (value12.Checked) sw.WriteLine(strNameSpce + value12.Value);
                    if (value13.Checked) sw.WriteLine(strNameSpce + value13.Value);
                    if (value14.Checked) sw.WriteLine(strNameSpce + value14.Value);
                    if (value15.Checked) sw.WriteLine(strNameSpce + value15.Value);
                    if (value16.Checked) sw.WriteLine(strNameSpce + value16.Value);
                    if (value17.Checked) sw.WriteLine(strNameSpce + value17.Value);
                    if (value18.Checked) sw.WriteLine(strNameSpce + value18.Value);
                    if (value19.Checked) sw.WriteLine(strNameSpce + value19.Value);
                    if (value20.Checked) sw.WriteLine(strNameSpce + value20.Value);
                }
            }
            lblPath.Text = "Data saved successfully.";
        }
        catch (Exception ex)
        {
            lblPath.Text += ex.Message;
        }
    }
    protected void btnReport_Click(object sender, EventArgs e)
    {
        DirectoryInfo dinfo = new DirectoryInfo(@"C:\Program Files (x86)\Jenkins\jobs\Demo\workspace\bin\Debug\Report");

        DirectoryInfo latestdir = dinfo.GetDirectories().OrderByDescending(f => f.CreationTime).FirstOrDefault();

        if (latestdir != null)
        {
            string strFileName = latestdir.FullName + @"\" + "Report.html";
            string[] filePaths = Directory.GetFiles(latestdir.FullName);
            System.Diagnostics.Process process = new System.Diagnostics.Process();
            process.StartInfo.UseShellExecute = true;
            process.StartInfo.FileName = strFileName;
            process.Start();
            //System.Diagnostics.Process.Start(strFileName);
        }
    }
}